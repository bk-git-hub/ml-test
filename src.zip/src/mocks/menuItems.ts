// src/mock/menu.ts

import { ResMenu } from '@/types/menu';
import { Menu } from '@/types/menu';

// ✅ mock 데이터
export const mockMenuItems: ResMenu[] = [
  {
    menu_id: 0,
    category_id: 0,
    menu_name: '삼겹살',
    menu_name_en: 'Pork Belly',
    menu_price: 18000,
    menu_img_url: 'https://via.placeholder.com/150/FFB6C1/FFFFFF?text=삼겹살',
  },
  {
    menu_id: 1,
    category_id: 0,
    menu_name: '목살',
    menu_name_en: 'Neck Meat',
    menu_price: 17000,
    menu_img_url: 'https://via.placeholder.com/150/FFB6C1/FFFFFF?text=목살',
  },
  {
    menu_id: 2,
    category_id: 0,
    menu_name: '볶음밥',
    menu_name_en: 'Fried Rice',
    menu_price: 8000,
    menu_img_url: 'https://via.placeholder.com/150/FFB6C1/FFFFFF?text=볶음밥',
  },
  {
    menu_id: 3,
    category_id: 1,
    menu_name: '콜라',
    menu_name_en: 'Coke',
    menu_price: 2000,
    menu_img_url: 'https://via.placeholder.com/150/87CEEB/FFFFFF?text=콜라',
  },
  {
    menu_id: 4,
    category_id: 1,
    menu_name: '사이다',
    menu_name_en: 'Sprite',
    menu_price: 2000,
    menu_img_url: 'https://via.placeholder.com/150/87CEEB/FFFFFF?text=사이다',
  },
  {
    menu_id: 5,
    category_id: 1,
    menu_name: '물',
    menu_name_en: 'Water',
    menu_price: 1000,
    menu_img_url: 'https://via.placeholder.com/150/87CEEB/FFFFFF?text=물',
  },
  {
    menu_id: 6,
    category_id: 2,
    menu_name: '참이슬',
    menu_name_en: 'Chamisul',
    menu_price: 4000,
    menu_img_url: 'https://via.placeholder.com/150/FFD700/FFFFFF?text=참이슬',
  },
  {
    menu_id: 7,
    category_id: 2,
    menu_name: '테라',
    menu_name_en: 'Terra',
    menu_price: 5000,
    menu_img_url: 'https://via.placeholder.com/150/FFD700/FFFFFF?text=테라',
  },
  {
    menu_id: 8,
    category_id: 2,
    menu_name: '하이볼',
    menu_name_en: 'Highball',
    menu_price: 8000,
    menu_img_url: 'https://via.placeholder.com/150/FFD700/FFFFFF?text=하이볼',
  },
];

// ✅ 변환 함수
export const mapResMenuToMenu = (resMenus: ResMenu[]): Menu[] => {
  return resMenus.map((item) => ({
    id: item.menu_id,
    name: item.menu_name,
    name_en: item.menu_name_en,
    price: item.menu_price,
    imageUrl: item.menu_img_url,
    categoryId: item.category_id,
  }));
};
