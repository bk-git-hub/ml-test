export interface Menu {
  id: number;
  name: string;
  name_en: string;
  price: number;
  imageUrl: string;
  categoryId: number;
}