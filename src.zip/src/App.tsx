// src/App.tsx

import AppRouter from './router';

const App = () => {
  return <AppRouter />;
};

export default App;
